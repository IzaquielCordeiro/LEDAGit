package adt.bst;

public class BSTImpl<T extends Comparable<T>> implements BST<T>
{

    protected BSTNode<T> root;

    public BSTImpl()
    {
        root = new BSTNode<T>();
    }

    public BSTNode<T> getRoot()
    {
        return this.root;
    }

    @Override
    public boolean isEmpty()
    {
        return root.isEmpty();
    }

    @Override
    public int height()
    {
        if (this.isEmpty()) return -1;
        return 1 + height(this.root);
    }

    private int height(BSTNode<T> node)
    {
        int sum = 0;

        if (node.isEmpty()) return sum;

        sum += 1 + height((BSTNode<T>) node.getLeft());
        sum += 1 + height((BSTNode<T>) node.getRight());

        return sum;
    }

    @Override
    public BSTNode<T> search(T element)
    {
        return search(root, element);
    }

    private BSTNode<T> search(BSTNode<T> node, T element)
    {
        if (element != null)
        {
            if (!node.isEmpty())
            {
                if (node.getData().equals(element)) return node;
                else
                {
                    if (element.compareTo(node.getData()) < 0) return search((BSTNode<T>) node.getLeft(), element);
                    if (element.compareTo(node.getData()) > 0) return search((BSTNode<T>) node.getRight(), element);
                }
            }
        }

        return new BSTNode<T>();
    }

    @Override
    public void insert(T element)
    {
        if (element != null) insert(root, element);
    }

    private void insert(BSTNode<T> node, T element)
    {

        if (node.isEmpty())
        {
            node.setData(element);
            node.setLeft(new BSTNode<>());
            node.setRight(new BSTNode<>());
        }
        else
        {
            if (element.compareTo(node.getData()) < 0) insert((BSTNode<T>) node.getLeft(), element);
            else if (element.compareTo(node.getData()) > 0) insert((BSTNode<T>) node.getRight(), element);
        }

    }


    @Override
    public BSTNode<T> maximum()
    {
        return maximum(root);
    }

    private BSTNode<T> maximum(BSTNode<T> node)
    {
        if (node.getRight().isEmpty()) return node;

        return maximum((BSTNode<T>) node.getRight());
    }

    @Override
    public BSTNode<T> minimum()
    {
        return minimum(root);
    }

    private BSTNode<T> minimum(BSTNode<T> node)
    {
        if (node.getLeft().isEmpty()) return node;

        return minimum((BSTNode<T>) node.getLeft());
    }

    @Override
    public BSTNode<T> sucessor(T element)
    {
        return sucessor(search(root, element), element);
    }

    private BSTNode<T> sucessor(BSTNode<T> node, T element)
    {
        BSTNode<T> sucessor = new BSTNode<>();

        if (!node.isEmpty())
        {
            if (node.getData().compareTo(element) > 0) sucessor = node;
            else if (!node.getRight().isEmpty()) sucessor = minimum((BSTNode<T>) node.getLeft());
            else
            {
                BSTNode<T> f = (BSTNode<T>) node.getParent();
                sucessor = sucessor(f, element);
            }
        }
        return sucessor;
    }

    @Override
    public BSTNode<T> predecessor(T element)
    {
        return predecessor(search(root, element), element);
    }

    private BSTNode<T> predecessor(BSTNode<T> node, T element)
    {
        BSTNode<T> predecessor = new BSTNode<>();

        if (!node.isEmpty())
        {
            if (node.getData().compareTo(element) < 0) predecessor = node;
            else if (!node.getLeft().isEmpty()) predecessor = maximum((BSTNode<T>) node.getLeft());
            else
            {
                BSTNode<T> f = (BSTNode<T>) node.getParent();
                predecessor = predecessor(f, element);
            }
        }
        return predecessor;
    }


    @Override
    public void remove(T element)
    {
        if (element != null) remove(search(element), element);
    }

    private void remove(BSTNode<T> node, T element)
    {
        if(!node.getLeft().isEmpty()) node = (BSTNode<T>)node.getLeft();
        else if(!node.getRight().isEmpty()) node = (BSTNode<T>)node.getRight();
        else node = new BSTNode<T>();
    }

    @Override
    public T[] preOrder()
    {
        T[] preOrderedArray = (T[]) new Object[size()];
        return preOrder(minimum(), preOrderedArray, 0);
    }

    private T[] preOrder(BSTNode<T> node, T[] preOrderedArray, int cont)
    {
        preOrderedArray[cont] = node.getData();

        if(!node.getParent().isEmpty()) preOrder((BSTNode<T>)node.getParent(), preOrderedArray, ++cont);
        if(!node.getRight().isEmpty()) preOrder((BSTNode<T>)node.getParent(), preOrderedArray, ++cont);

        return preOrderedArray;
    }

    @Override
    public T[] order()
    {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Not implemented yet!");
    }

    @Override
    public T[] postOrder()
    {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Not implemented yet!");
    }

    /**
     * This method is already implemented using recursion. You must understand
     * how it work and use similar idea with the other methods.
     */
    @Override
    public int size()
    {
        return size(root);
    }

    private int size(BSTNode<T> node)
    {
        int result = 0;
        // base case means doing nothing (return 0)
        if (!node.isEmpty())
        { // indusctive case
            result = 1 + size((BSTNode<T>) node.getLeft()) + size((BSTNode<T>) node.getRight());
        }
        return result;
    }

}
