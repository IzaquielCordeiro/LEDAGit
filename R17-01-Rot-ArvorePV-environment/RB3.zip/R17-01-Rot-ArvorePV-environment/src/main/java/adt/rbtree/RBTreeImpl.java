package adt.rbtree;

import adt.bst.BSTImpl;
import adt.bst.BSTNode;
import adt.bt.BTNode;
import adt.bt.Util;
import adt.rbtree.RBNode.Colour;

import java.util.ArrayList;

public class RBTreeImpl<T extends Comparable<T>> extends BSTImpl<T> implements RBTree<T>
{

   public RBTreeImpl()
   {
      this.root = new RBNode<T>();
   }

   protected int blackHeight()
   {
      int bh = 0;

      bh += blackHeight((RBNode<T>) this.root);

      return bh;
   }

   private int blackHeight(RBNode<T> node)
   {
      int altura = 0;
      if (node != null && !node.isEmpty())
      {
         if (node.getColour() == Colour.BLACK)
         {
            altura = 1 + Math.max(blackHeight((RBNode<T>) node.getLeft()), blackHeight((RBNode<T>) node.getRight()));
         }
         else
         {
            altura = Math.max(blackHeight((RBNode<T>) node.getLeft()), blackHeight((RBNode<T>) node.getRight()));
         }
      }
      return altura;
   }

   protected boolean verifyProperties()
   {
      boolean resp = verifyNodesColour() && verifyNILNodeColour() && verifyRootColour() && verifyChildrenOfRedNodes() && verifyBlackHeight();

      return resp;
   }

   /**
    * The colour of each node of a RB tree is black or red. This is guaranteed
    * by the type Colour.
    */
   private boolean verifyNodesColour()
   {
      return true; // already implemented
   }

   /**
    * The colour of the root must be black.
    */
   private boolean verifyRootColour()
   {
      return ((RBNode<T>) root).getColour() == Colour.BLACK; // already
      // implemented
   }

   /**
    * This is guaranteed by the constructor.
    */
   private boolean verifyNILNodeColour()
   {
      return true; // already implemented
   }

   /**
    * Verifies the property for all RED nodes: the children of a red node must
    * be BLACK.
    */
   private boolean verifyChildrenOfRedNodes()
   {
      return verifyChildrenOfRedNodes((RBNode<T>) this.root);
   }

   private boolean verifyChildrenOfRedNodes(RBNode<T> node)
   {
      if (node != null && !node.isEmpty())
      {
         RBNode<T> leftNode = (RBNode<T>) node.getRight();
         RBNode<T> rightNode = (RBNode<T>) node.getLeft();

         if (node.getColour().equals(Colour.RED))
         {
            if ((leftNode.getColour().equals(Colour.RED)) || (rightNode.getColour().equals(Colour.RED)))
            {
               return false;
            }
         }
         else
         {
            verifyChildrenOfRedNodes((RBNode<T>) node.getLeft());
            verifyChildrenOfRedNodes((RBNode<T>) node.getRight());
         }
      }

      return true;
   }

   /**
    * Verifies the black-height property from the root.
    */
   private boolean verifyBlackHeight()
   {
      // TODO Implement your code here
      throw new UnsupportedOperationException("Not implemented yet!");
   }

   @Override
   public void insert(T value)
   {
      super.insert(value);
      RBNode<T> node = (RBNode<T>) super.search(value);
      node.setColour(Colour.RED);
      fixUpCase1(node);
   }

   @Override
   public RBNode<T>[] rbPreOrder()
   {
      return rbPreOrder(root, new ArrayList<RBNode<T>>()).toArray(new RBNode[size()]);
   }

   private ArrayList<RBNode<T>> rbPreOrder(BSTNode<T> node, ArrayList<RBNode<T>> rbNodes)
   {
      if (node != null && !node.isEmpty())
      {
         rbNodes.add((RBNode<T>) node);

         rbPreOrder((BSTNode<T>) node.getLeft(), rbNodes);
         rbPreOrder((BSTNode<T>) node.getRight(), rbNodes);
      }

      return rbNodes;
   }

   // FIXUP methods
   protected void fixUpCase1(RBNode<T> node)
   {
      if (node.getParent() == null || node.getParent().isEmpty()) node.setColour(Colour.BLACK);
      else fixUpCase2(node);
   }

   protected void fixUpCase2(RBNode<T> node)
   {
      if (!((RBNode<T>) node.getParent()).getColour().equals(Colour.BLACK)) fixUpCase3(node);
   }

   protected void fixUpCase3(RBNode<T> node)
   {
      RBNode<T> parent = (RBNode<T>) node.getParent();
      RBNode<T> uncle = getUncle(node);
      RBNode<T> grandfather = (RBNode<T>) parent.getParent();

      if (uncle != null && !uncle.isEmpty() && uncle.getColour().equals(Colour.RED))
      {
         parent.setColour(Colour.BLACK);
         uncle.setColour(Colour.BLACK);
         grandfather.setColour(Colour.RED);
         fixUpCase1(grandfather);
      }
      else fixUpCase4(node);
   }

   protected void fixUpCase4(RBNode<T> node)
   {
      RBNode<T> next = node;
      RBNode<T> parent = (RBNode<T>) node.getParent();
      RBNode<T> grandfather = (RBNode<T>) parent.getParent();

      if (node.equals(parent.getRight()) && parent.equals(grandfather.getLeft()))
      {
         Util.leftRotation(parent);
         next = (RBNode<T>) next.getLeft();
      }
      else if (node.equals(parent.getLeft()) && parent.equals(grandfather.getRight()))
      {
         Util.rightRotation(parent);
         next = (RBNode<T>) node.getRight();
      }

      fixUpCase5(next);
   }

   protected void fixUpCase5(RBNode<T> node)
   {
      RBNode<T> parent = (RBNode<T>) node.getParent();
      RBNode<T> grandfather = (RBNode<T>) parent.getParent();

      parent.setColour(Colour.BLACK);
      grandfather.setColour(Colour.RED);

      if (node.equals(parent.getLeft())) Util.rightRotation(grandfather);
      else Util.leftRotation(grandfather);
   }

   private RBNode<T> getUncle(RBNode<T> node)
   {
      if (node != null && !node.isEmpty())
      {
         RBNode<T> parent = (RBNode<T>) node.getParent();

         RBNode<T> grandfather = (RBNode<T>) parent.getParent();

         if (grandfather != null && !grandfather.isEmpty())
         {
            if (parent.getLeft().equals(node)) return (RBNode<T>) parent.getRight();
            if (parent.getRight().equals(node)) return (RBNode<T>) parent.getLeft();
         }
      }
      return null;
   }
}
